# Hướng dẫn: Cube Radar cho Aion 2

Cube Radar hiển thị trong một mini-radar nhỏ nằm trên game vị trí các Hidden Cube hiện có: khoảng cách, hướng và độ cao.
Chương trình chỉ đọc thụ động lưu lượng mạng của Aion 2 (giống Wireshark). Nó không đọc bộ nhớ, không thay đổi gì trong game
và không gửi gì vào game. Chương trình chỉ kết nối Internet để tìm bản cập nhật trên GitHub, và việc này có thể tắt
(xem [Cập nhật](#8-cập-nhật)).

> **Cảnh báo:** theo lời một tác giả công cụ khác, bộ phận hỗ trợ của NCSOFT coi phần mềm đọc dữ liệu game là vi phạm
> điều khoản sử dụng. Bạn tự chịu rủi ro khi sử dụng.

> **Về bản này:** đây là bản chỉ dành cho Hidden Cube và đã Việt hóa. Chức năng hiển thị người chơi / đối thủ PvP của bản gốc
> đã được loại bỏ.

## 1. Điều kiện

- Windows 10 hoặc 11 (64 bit)
- **Npcap**, miễn phí tại [npcap.com](https://npcap.com). Chạy bộ cài với các tùy chọn mặc định.
- Aion 2 **Global** ở chế độ **cửa sổ hoặc toàn màn hình không viền**. Trên chế độ toàn màn hình độc quyền, Windows không
  thể hiển thị gì đè lên game.

## 2. Khởi động và thoát

1. Tải `Cube.Radar.exe` từ [Releases](https://github.com/dr89mh/aion2-cube-radar/releases/latest) (hoặc dùng tệp exe do bạn
   tự build) và đặt ở đâu cũng được, ví dụ ngoài màn hình Desktop. Không cần cài đặt.
2. Nhấp đúp vào tệp exe. Nếu Windows SmartScreen báo ứng dụng không xác định: “More info” → “Run anyway”. Sau đó Windows hỏi
   Cube Radar có được phép thay đổi hệ thống không: chọn “Yes” (quyền admin, để mini-radar nhận biết được phím Alt, xem
   [Sử dụng](#4-sử-dụng)).
3. Một biểu tượng radar xuất hiện ở góc dưới bên phải thanh tác vụ (có thể nằm sau mũi tên nhỏ ^). Chương trình không có cửa
   sổ chính, radar chạy ngầm.
4. Mở Aion 2 và vào thế giới game. Mini-radar xuất hiện ngay khi Aion 2 là cửa sổ đang hoạt động.

**Thoát:** ⚙ trên mini-radar → “Thoát radar”, hoặc nhấp chuột phải vào biểu tượng radar ở thanh tác vụ → “Thoát”.

Chỉ chạy được một radar tại một thời điểm; nhấp đúp lần thứ hai sẽ báo “Cube Radar đang chạy rồi”.

## 3. Đọc mini-radar

```
┌ CUBE RADAR   ● Vị trí 2 giây   120 m ⚙ ┐   Dòng đầu: tuổi vị trí của bạn, zoom, cài đặt
│                 B                      │   Bốn hướng quanh vòng tròn: B ở trên, Đ bên phải, N ở dưới, T bên trái
│          ·  ·  ·  ·  ·                 │
│       ·     60 m        ·              │   Các vòng tròn kèm số mét
│      ·        ▲ 86 m ▲38   ·           │   Cube: cách 86 m, cao hơn bạn 38 m
│      ·         ●            ·          │   ● = bạn, đường mảnh = vệt di chuyển gần nhất
│       ·                   ·    »       │   » = cube nằm ngoài phạm vi zoom, theo hướng này
│          ·  ·  ·  ·  ·                 │
└────────────────────────────────────────┘
```

**Bốn hướng:** radar luôn xoay theo hướng Bắc nên chữ **B** (Bắc) ở trên, **Đ** (Đông) bên phải, **N** (Nam) ở dưới và **T** (Tây)
bên trái. Chúng là hướng của thế giới game, không phải hướng nhân vật đang quay mặt tới (đối chiếu với minimap trong game; nếu
lệch thì đổi “Hướng Bắc” trong Cài đặt).

**Bạn:** chấm xanh ở giữa là bạn. Đường xanh mảnh là vệt di chuyển gần nhất của bạn; nó cho biết bạn đến từ đâu, vì game
không gửi hướng nhìn. Vòng tròn nét đứt là tầm nhìn khoảng 100 m: máy chủ chỉ gửi các cube trong phạm vi này.

**Cube:**

- Biểu tượng theo độ cao: **▲** = cao hơn bạn, **▼** = thấp hơn bạn, **■** = xấp xỉ cùng độ cao (± 3 m).
- Chú thích: `86 m ▲38` nghĩa là cách 86 m và cao hơn bạn 38 m; `≈` nghĩa là cùng độ cao.
- Màu theo trạng thái:
  - **xanh lá, đặc:** đang thấy
  - **cam, rỗng:** ngoài tầm nhìn, nhiều khả năng vẫn còn đó
  - **vàng:** đang được mở
- Cube đã mở hoặc đã biến mất sẽ biến khỏi radar.
- Mỗi khi có cube mới sẽ có một tiếng bíp.

**Gợi ý đi hướng nào:** dòng chữ ở đáy radar cho biết cube gần nhất nằm ở đâu so với bạn, ví dụ `↗ Trước-phải · 86 m`
(tám hướng: Trước, Trước-phải, Phải, Sau-phải, Sau, Sau-trái, Trái, Trước-trái). Mũi tên ngắn cạnh chấm xanh của bạn là
**hướng bạn đang di chuyển**, chính là “phía trước” dùng để tính.

- Game **không gửi hướng nhìn** của nhân vật, nên “phía trước” là hướng bạn vừa đi (từ vị trí cách đây ít nhất 5 m, trong
  20 giây gần nhất). Hãy chạy thẳng vài bước để radar biết hướng; khi đứng yên hoặc chỉ xoay camera, hướng có thể sai.
- Khi chưa biết hướng di chuyển, dòng gợi ý chuyển sang hướng la bàn, ví dụ `hướng ĐB · 86 m`.

**Vị trí của bạn (dòng đầu, có chấm màu):** game không gửi vị trí của bạn liên tục, mà chỉ khi có sự kiện, ví dụ khi bạn
thi triển buff hoặc bị tấn công.

- `Vị trí 2 giây` màu **xanh lá**: mới (đến 5 giây)
- `Vị trí 20 giây` màu **cam**: hơi cũ (đến 30 giây)
- `Vị trí 90 giây` màu **đỏ**: đã cũ; khoảng cách có thể lệch đáng kể
- `± 40 m`: vị trí chỉ là ước lượng; vòng tròn chấm quanh bạn cho biết độ sai số.
- `Vị trí ?` hoặc “chưa rõ vị trí của bạn”: **thi triển một buff lên chính mình** một lần là sẽ có.

## 4. Sử dụng

### Phím tắt và khả năng hiển thị

- **Di chuyển:** `Ctrl+Shift+F11` mở cài đặt. Khi cài đặt đang mở, radar luôn hiện và có thể kéo bằng chuột. Vị trí được
  lưu lại. Nhấn `Ctrl+Shift+F11` lần nữa để đóng cài đặt.
- **Zoom:** `Ctrl+Shift+F12`, hoặc lăn chuột trên radar (lên = gần hơn) khi cài đặt đang mở. Các mức: 60 / 120 / 250 m.
- **Tắt / bật hẳn:** `Ctrl+Shift+F10`.
- **Tự động ẩn:** radar chỉ hiện khi Aion 2 là cửa sổ đang hoạt động. Trong menu (khi con trỏ chuột đang hiện) nó cũng tự ẩn,
  kể cả khi con trỏ nằm ngay trên nó, nên không bao giờ che menu. Khi bạn giữ `Alt` (Aion 2 lúc đó hiện con trỏ), radar vẫn
  hiện cho đến khi bạn thả phím. Cả hai hành vi đều có thể tắt trong phần cài đặt.
- **Tại sao cần quyền admin?** Aion 2 chạy với quyền admin, và khi nó ở phía trước, Windows giấu trạng thái bàn phím khỏi các
  chương trình không có quyền này. Chỉ khi có quyền admin, radar mới biết `Alt` đang được giữ và không coi con trỏ là một
  menu. Vì vậy Windows hỏi khi khởi động. Nếu bạn từ chối, radar vẫn chạy, chỉ là `Alt` sẽ làm nó ẩn đi như khi mở menu.
  Trình duyệt và Explorer vẫn được mở không có quyền admin.
- Radar luôn nằm phía trước nhưng không bao giờ lấy mất tiêu điểm của game.

**Nhấp chuột phải vào biểu tượng radar ở thanh tác vụ:**
Cài đặt (cũng có thể nhấp đúp vào biểu tượng), Bật/tắt overlay, Đổi zoom, Mở giao diện web, Mở thư mục bản ghi, Thoát.

## 5. Cài đặt

Mở bằng `Ctrl+Shift+F11` (dùng được cả trong game), nhấp đúp vào biểu tượng radar, hoặc nút ⚙ ở góc trên bên phải mini-radar.
Thay đổi có hiệu lực ngay và được lưu. Khi cửa sổ đang mở, mini-radar luôn hiển thị để bạn có thể di chuyển và zoom.

- **Âm thanh khi có cube mới:** bật/tắt, “Thử”, âm lượng (kéo thanh trượt sẽ nghe thử) và tùy chọn dùng tệp `.wav` riêng thay
  cho tiếng bíp mặc định. Trong bộ trộn âm lượng của Windows, “Cube Radar” là một ứng dụng riêng và có thể chỉnh hoặc tắt
  tiếng ở đó.
- **Tiếng tích khi đến gần:** hai tùy chọn dưới phần âm thanh. Khi có cube trong phạm vi (dưới ~80 m), radar phát tiếng
  “tích” ngắn: **càng gần càng dồn dập và cao hơn** (từ 2 giây một tiếng xuống còn 0,15 giây một tiếng khi dưới 3 m).
  Với tùy chọn thứ hai, tiếng tích **nghiêng sang tai trái hoặc phải** theo hướng cube (nên đeo tai nghe); cube nằm phía sau
  bạn nghe **trầm hơn**, vì hai tai không phân biệt được trước/sau. Tiếng tích im khi overlay đang ẩn (game không ở phía trước,
  đang mở menu) và không đè lên tiếng bíp báo cube mới. Hai hạn chế: tiếng chỉ đổi khi game gửi vị trí mới của bạn, và hướng
  trái/phải cũng tính theo hướng bạn di chuyển (xem trên).
- **Overlay:** zoom, kích thước (75–150 %), độ đục của radar.
- **Hướng Bắc:** nếu cube chỉ sai hướng so với minimap trong game (bị đối xứng hoặc xoay 90°), hãy đổi ở đây cho đến khi
  khớp. Mặc định là “−Y”.
- **Khi nào overlay được hiển thị?** “Chỉ khi Aion 2 ở cửa sổ phía trước”, “Ẩn khi mở menu” và “Chạy với quyền admin để nhận
  biết phím Alt” (có hiệu lực từ lần khởi động sau).
- **Cập nhật:** bật/tắt tự động tìm, “Kiểm tra ngay”, “Cập nhật ngay”, “Các phiên bản trên GitHub” (xem
  [Cập nhật](#8-cập-nhật)).
- **Khác:** Đặt lại vị trí (khi radar bị lạc ra ngoài màn hình), Mở giao diện web, Mở thư mục bản ghi, Thoát radar.

## 6. Giao diện web (tùy chọn)

“Mở giao diện web” sẽ mở trong trình duyệt một giao diện lớn (`http://127.0.0.1:5313`, chỉ truy cập được từ máy của bạn):

- radar lớn kèm dải độ cao
- bản đồ với mọi cube của phiên và vệt di chuyển của bạn
- danh sách với khoảng cách, hướng la bàn (B = Bắc, Đ = Đông, N = Nam, T = Tây), độ cao, “thấy lần đầu cách đây”,
  “đã tồn tại” và trạng thái; xuất ra CSV/JSON
- “Âm thanh” và “Thông báo” để phát âm thanh hoặc hiện thông báo trên màn hình mỗi khi có cube mới

## 7. Hoạt động ở đâu?

Hidden Cube đã được xác nhận ở **Verteron**. Ở các khu vực khác, ví dụ **Altgard**, mã nhận dạng cube chưa được xác nhận
bằng dữ liệu của chúng tôi. Radar sẽ tự học ngay khi một cube được mở bằng chìa khóa ở gần bạn.

## 8. Cập nhật

Radar tìm phiên bản mới trên GitHub khi khởi động và sau đó mỗi 6 giờ. Từ 0.9.0 nó kiểm tra kho `dr89mh/aion2-cube-radar`.

> **Lưu ý với bản Việt hóa:** kho đó là bản gốc (tiếng Đức, có hiển thị đối thủ PvP). Nếu bạn xác nhận cài một bản cập nhật từ đó,
> bản Việt hóa sẽ bị thay thế. Nếu không muốn điều đó, hãy tắt “Tự động tìm bản cập nhật”.

- Khi có bản mới, một thông báo hiện ở góc dưới bên phải, và trong menu của biểu tượng radar có mục “Cài bản cập nhật …”.
  Nhấp vào đó (hoặc Cài đặt → “Cập nhật ngay”) sẽ hỏi xác nhận, tải bản mới, kiểm tra mã SHA-256, thoát radar và vài giây sau
  khởi động lại bằng phiên bản mới. Cài đặt và dữ liệu được giữ nguyên. Không có gì được cài khi chưa có sự đồng ý của bạn.
- Trong lúc đó, một tệp `Cube Radar.update.exe` xuất hiện tạm thời cạnh tệp exe; nó tự biến mất sau khi khởi động lại.
- GitHub thấy gì: một yêu cầu lấy phiên bản mới nhất kèm địa chỉ IP của bạn và mã định danh `CubeRadar/<Phiên bản>`. Không
  gì khác, đặc biệt là không có dữ liệu game.
- **Tắt:** Cài đặt → “Tự động tìm bản cập nhật”. Khi đó radar hoàn toàn không kết nối Internet; “Kiểm tra ngay” chỉ hỏi khi
  bạn nhấn vào nó.
- Nếu tệp exe nằm trong thư mục không có quyền ghi (ví dụ trong “Program Files”), nó không thể tự thay thế. Khi đó hãy tải bản
  mới từ [trang phát hành](https://github.com/dr89mh/aion2-cube-radar/releases/latest).

## 9. Khắc phục sự cố

- **Radar không hiện:** Aion 2 có đang là cửa sổ hoạt động không? Game có chạy ở chế độ cửa sổ hoặc toàn màn hình không viền
  không? Có lỡ tắt bằng `Ctrl+Shift+F10` không? Nếu cần: Cài đặt → “Đặt lại vị trí”.
- **“đang chờ dữ liệu …” mãi không hết:** bạn đã vào thế giới game chưa? Npcap đã được cài chưa? Nếu khi cài Npcap bạn đã tích
  “Restrict Npcap driver's access to Administrators only”, hãy nhấp chuột phải vào tệp exe → “Run as administrator”.
- **`Vị trí ?` hoặc “chưa rõ vị trí của bạn”:** thi triển một buff lên chính mình.
- **Sai hướng:** Cài đặt → đổi “Hướng Bắc”.
- **Không có âm thanh:** Cài đặt → “Phát âm thanh” đã bật chưa? Nhấn “Thử”. Kiểm tra “Cube Radar” trong bộ trộn âm lượng của
  Windows.
- **Sau bản vá game không còn thấy cube:** có thể game đã đổi số hiệu gói tin. Giao diện web sẽ hiện một cảnh báo đỏ. Hãy chờ
  phiên bản mới.
- **Giao diện web vẫn còn tiếng Đức / còn hiện đối thủ:** có thể trình duyệt đang dùng bản cũ trong bộ nhớ đệm (nhấn Ctrl+F5),
  hoặc thư mục `%LOCALAPPDATA%\CubeRadar\app` còn tệp của bản cũ: hãy thoát radar, xóa thư mục `app` đó rồi chạy lại.

## 10. Dữ liệu và gỡ cài đặt

- Mọi thứ radar lưu đều nằm trong `%LOCALAPPDATA%\CubeRadar` (nhập vào thanh địa chỉ Explorer): bản ghi, cơ sở dữ liệu cube,
  cài đặt, log.
- Các bản ghi chứa lưu lượng game bạn đã ghi lại, **bao gồm cả tên nhân vật và chat**. Đừng đăng chúng công khai ở bất cứ đâu,
  kể cả trong một issue trên GitHub.
- **Gỡ cài đặt:** thoát radar, xóa `Cube.Radar.exe` và xóa thư mục `%LOCALAPPDATA%\CubeRadar`. Npcap có thể gỡ qua “Apps”
  trong Cài đặt của Windows nếu cần.

## Đánh dấu (tùy chọn)

Ai muốn giúp cải thiện chương trình có thể đặt các đánh dấu vào bản ghi khi chơi. Chúng chỉ nằm cục bộ trong bản ghi:

- `Ctrl+Shift+F5`: đã thấy cube trong game
- `Ctrl+Shift+F6`: đã mở cube
- `Ctrl+Shift+F7`: cube ra ngoài tầm nhìn
- `Ctrl+Shift+F8`: cube quay lại tầm nhìn
- `Ctrl+Shift+F9`: ghi chú
