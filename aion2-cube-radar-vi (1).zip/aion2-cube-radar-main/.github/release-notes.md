Mini-radar cho Aion 2 (Global): Hidden Cube với khoảng cách, hướng và độ cao. Chương trình chỉ đọc thụ động lưu lượng mạng của Aion 2, không đọc bộ nhớ, không thay đổi gì trong game và không gửi gì vào game. Giao diện tiếng Việt, không hiển thị người chơi / đối thủ PvP.

## Mới trong {{VERSION}}

{{CHANGES}}

## Tải về

Tải **`Cube.Radar.exe`** ở mục “Assets” bên dưới rồi nhấp đúp. Không cần cài đặt, .NET đã được đóng gói sẵn. Nếu radar đang chạy, hãy thoát nó từ biểu tượng khay hệ thống trước.

- **Điều kiện:** Windows 10/11 (64 bit), [Npcap](https://npcap.com) (bộ cài với tùy chọn mặc định), Aion 2 Global ở chế độ cửa sổ hoặc toàn màn hình không viền
- **SmartScreen:** tệp exe chưa được ký. Nếu Windows báo ứng dụng không xác định: “More info” → “Run anyway”.
- **Cách dùng:** xem [Hướng dẫn](https://github.com/{{REPO}}/blob/{{TAG}}/docs/ANLEITUNG.md)

> **Cảnh báo:** theo lời một tác giả công cụ khác, bộ phận hỗ trợ của NCSOFT coi phần mềm đọc dữ liệu game là vi phạm điều khoản sử dụng. Bạn tự chịu rủi ro khi sử dụng.

## Mã kiểm tra

SHA-256 của `Cube.Radar.exe`:
`{{SHA256}}`

Được GitHub Actions build từ phiên bản [`{{TAG}}`](https://github.com/{{REPO}}/tree/{{TAG}}).

## Mã nguồn

GPL-3.0. “Source code” ở mục “Assets” bên dưới đúng là mã nguồn của phiên bản này.
