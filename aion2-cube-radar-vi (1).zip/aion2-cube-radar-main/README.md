# Cube Radar: radar Hidden Cube cho Aion 2

**Cube Radar** là overlay mini-radar cho **Aion 2 (Global)**, hiển thị trực tiếp vị trí các **Hidden Cube** (khối ẩn):
khoảng cách, hướng và độ cao. Chương trình đọc lưu lượng mạng máy chủ → máy khách qua Npcap, giống như Wireshark.
Nó không đọc bộ nhớ game, không chèn DLL (injection) và không gửi bất cứ thứ gì vào game. Kết nối Internet duy nhất là
tính năng tìm bản cập nhật trên GitHub (có thể tắt; chỉ tải tệp exe hoàn chỉnh).

> Bản này là bản **chỉ dành cho Hidden Cube** và đã **Việt hóa**: giao diện, overlay, cửa sổ cài đặt, thông báo và tài liệu
> đều bằng tiếng Việt. Chức năng hiển thị người chơi / đối thủ PvP (tên, phe, cấp bậc, khoảng cách) đã được loại bỏ hoàn toàn.

- **Mini-radar nằm trên game:** các Hidden Cube ở gần bạn với khoảng cách, hướng và độ cao (▲ cao hơn bạn, ▼ thấp hơn
  bạn), phát âm thanh mỗi khi có cube mới
- **Gợi ý đi hướng nào** (“↗ Trước-phải · 86 m”, tính theo hướng bạn đang di chuyển vì game không gửi hướng nhìn) và
  **tiếng tích dồn dập hơn khi đến gần**, có thể nghiêng sang tai trái/phải theo hướng cube (nên dùng tai nghe)
- **Trạng thái từng cube:** đang thấy, ngoài tầm nhìn, đang được mở, đã mở, đã biến mất
- **Giao diện web** với bản đồ, danh sách và cơ sở dữ liệu điểm xuất hiện riêng (xuất CSV/JSON)
- **Một tệp exe** cho Windows 10/11, không cần cài đặt, tự cập nhật khi bạn đồng ý
- Đã xác nhận ở **Verteron**; ở khu vực khác, radar tự học mã nhận dạng cube
  ([Hoạt động ở đâu?](docs/ANLEITUNG.md#7-hoạt-động-ở-đâu))

## Tải về

Bản dựng sẵn cho Windows 10/11 (64 bit): vào mục [**Releases**](https://github.com/dr89mh/aion2-cube-radar/releases/latest)
tải tệp `Cube.Radar.exe` rồi nhấp đúp để chạy. Không cần cài đặt, .NET đã được đóng gói sẵn.
Điều kiện: đã cài [Npcap](https://npcap.com) (chạy bộ cài với các tùy chọn mặc định). Khi khởi động, Windows sẽ hỏi quyền
admin để overlay nhận biết được phím Alt (có thể tắt, xem bên dưới). Cách đọc và sử dụng mini-radar có trong
**[Hướng dẫn](docs/ANLEITUNG.md)**.

> **Lưu ý về cập nhật:** tính năng tìm bản cập nhật vẫn trỏ tới kho GitHub gốc (`dr89mh/aion2-cube-radar`). Bản gốc
> là tiếng Đức và có hiển thị đối thủ PvP; nếu bạn xác nhận cài bản cập nhật đó, nó sẽ thay thế bản Việt hóa này.
> Nếu không muốn, hãy tắt “Tự động tìm bản cập nhật” trong ⚙ → Cập nhật.

> **Cảnh báo:** theo lời một tác giả công cụ khác, bộ phận hỗ trợ của NCSOFT coi phần mềm đọc dữ liệu game là vi phạm
> điều khoản sử dụng. Bạn tự chịu rủi ro khi sử dụng.

## Cấu trúc

Tình trạng: **Giai đoạn 3 (Radar) đã nghiệm thu**. Hidden Cube đã được nhận diện ở Verteron (template 1200039 và 1200041,
bán kính gửi dữ liệu ≈ 100 m). Vị trí của chính bạn lấy từ bốn nguồn gắn với sự kiện. Mọi phát hiện kỹ thuật nằm trong
[`docs/FINDINGS.md`](docs/FINDINGS.md) (tài liệu nghiên cứu giao thức, giữ nguyên bản gốc).

| Đường dẫn | Nội dung |
|---|---|
| `src/CubeRadar.Core` | Bắt gói tin (Npcap/SharpPcap), nhận diện luồng, ghép lại TCP, tách frame/LZ4 (dựa trên cyberbadger6969/aion2-dps-meter, GPL-3.0), ghi pcapng, dump JSONL, thống kê opcode |
| `src/CubeRadar.Core/Radar` | `RadarEngine` (trạng thái cube, ID/vị trí của bạn, ring-fix, tự học template), kho SQLite, chỉ mục điểm xuất hiện |
| `src/CubeRadar.Cli` | `cuberadar`: `radar`, `dump live`, `dump <tệp>`, `census`, `devices`, `conns`; đánh dấu (marker) bằng phím tắt toàn cục hoặc console; giao diện web trong `wwwroot/` |
| `tests/CubeRadar.Tests` | xunit: test frame tổng hợp, pcapng khứ hồi, fixture luồng thật, test chức năng Cube |
| `tests/cube-ui.test.cjs` | test giao diện web bằng Node (`node --test tests/cube-ui.test.cjs`) |
| `tools/` | Python (chỉ thư viện chuẩn): `a2wire.py` (bộ giải mã độc lập), `census.py`, `crosscheck.py`, `make_fixture.py`, `objects.py`, `radius.py`, `selfscan.py`, `selftrack.py`, `ringfix.py` |
| `config/opcodes.json` | Tên opcode kèm mức độ xác thực, để vá lỗi khi game cập nhật mà không phải sửa code |
| `config/cubes.json` | Nhận dạng cube: template theo khu vực, vật phẩm mở, bán kính gửi dữ liệu đã đo |
| `config/radar.json` | Opcode của radar, tự kiểm tra, trục Bắc, thời gian giữ, đường dẫn danh sách điểm (tùy chọn) |
| `data/radar.db` | cơ sở dữ liệu điểm xuất hiện của riêng bạn (SQLite, không nằm trong Git) |
| `fixtures/` | các đoạn luồng thật (hex) kèm frame mong đợi |
| `captures/` | các bản ghi (không nằm trong Git) |

## Build và kiểm thử

Cần **.NET SDK 10** trên Windows.

```powershell
dotnet build CubeRadar.slnx -c Release
dotnet test CubeRadar.slnx -c Release
node --test tests/cube-ui.test.cjs
```

Tệp thực thi nằm ở `src\CubeRadar.Cli\bin\Release\net10.0-windows\cuberadar.exe`. Chạy nhanh: `.\cuberadar.cmd`.

## Phát hành phiên bản mới

GitHub tự build và phát hành tệp exe ([`.github/workflows/release.yml`](.github/workflows/release.yml)):

1. Tăng `<Version>` trong `src/CubeRadar.Cli/CubeRadar.Cli.csproj` và `src/CubeRadar.Core/CubeRadar.Core.csproj`,
   commit rồi push.
2. Tạo tag kèm mô tả và push:
   ```powershell
   git tag -a v0.8.1 -m "- Điều gì mới, mỗi ý một dòng"
   git push origin v0.8.1
   ```
   Mô tả của tag sẽ thành mục “Mới trong 0.8.1” của bản phát hành. Nếu không có mô tả, sẽ dùng tiêu đề các commit kể từ tag trước.
3. Action kiểm tra tag khớp với phiên bản, chạy test, build `Cube Radar.exe` và tạo bản phát hành với `Cube.Radar.exe` cùng mã
   kiểm tra.

Ở máy cục bộ, `tools\package.ps1` build cùng tệp exe đó; nếu radar đang chạy, nó sẽ được tắt trước bằng `--quit`.

## Radar

**Một tệp duy nhất để chia sẻ:** `powershell -File tools\package.ps1` tạo `dist\Cube Radar.exe`.
- Tệp chứa sẵn .NET, giao diện web và cấu hình mặc định; nhấp đúp là chạy overlay ngay, không có cửa sổ console.
- Dữ liệu (bản ghi, cơ sở dữ liệu, cài đặt, log) nằm trong `%LOCALAPPDATA%\CubeRadar`.
- Một tệp cấu hình riêng trong `%LOCALAPPDATA%\CubeRadar\config\` (ví dụ `radar.json` với opcode mới sau bản vá game)
  được ưu tiên hơn bản tích hợp sẵn. Tệp `radar.json` của phiên bản cũ vẫn đọc được: các khóa `player_*` bị bỏ qua.
- Biểu tượng chương trình do `tools\make_icon.ps1` tạo (`assets\cuberadar.ico`).

Trong kho mã nguồn:

```powershell
.\cuberadar.cmd radar      # giao diện đầy đủ: trình duyệt + overlay + console
.\overlay.cmd              # chỉ overlay: không trình duyệt, không console, có biểu tượng khay
```

**Chế độ chỉ overlay** (`overlay.cmd` hoặc `radar --overlay-only`):
- Chương trình chạy ngầm; chỉ có mini-radar hiện trên game.
- Biểu tượng ở khay hệ thống (góc dưới bên phải), nhấp chuột phải: Cài đặt (cũng có thể nhấp đúp), Bật/tắt overlay, Đổi zoom,
  “Mở giao diện web” và “Thoát”.
- **Cài đặt** mở bằng nút ⚙ ở góc trên bên phải overlay hoặc từ biểu tượng khay. Thay đổi có hiệu lực ngay và được lưu:
  - Bật/tắt âm thanh kèm nút “Thử”, âm lượng (kéo thanh trượt sẽ nghe thử), tùy chọn dùng tệp .wav riêng.
    Trong bộ trộn âm lượng của Windows, “Cube Radar” xuất hiện như một ứng dụng riêng ngay từ khi khởi động,
    độc lập với “Âm thanh hệ thống”.
  - Zoom, kích thước (75–150 %) và độ đục của radar
  - Hướng Bắc
  - “Chỉ khi Aion 2 ở phía trước” và “Ẩn khi mở menu”
  - Các nút: Đặt lại vị trí, Mở giao diện web, Thoát radar
- Đầu ra được ghi vào `captures\radar_<ngày_giờ>\radar.log`. Việc ghi dữ liệu, cơ sở dữ liệu, tiếng bíp và phím tắt đánh
  dấu vẫn hoạt động như bình thường.

Giao diện đầy đủ mở `http://127.0.0.1:5313` trong trình duyệt.
- **Radar** hiển thị khu vực quanh bạn (Bắc ở trên, các vòng tròn, tầm nhìn ≈ 100 m vẽ nét đứt).
- **Độ cao:** ▲ = cube cao hơn bạn, ▼ = thấp hơn bạn, ■ = cùng độ cao (± 3 m). Dải độ cao bên phải radar lấy độ cao của bạn
  làm đường giữa. Trong danh sách có dòng như “▲ cao hơn bạn 38 m”. Nếu vị trí của bạn cũ hơn 5 giây, tuổi của nó được ghi kèm.
- **Bản đồ** hiển thị mọi cube, vệt di chuyển của bạn và, nếu có, các điểm có thể xuất hiện của khu vực.
- **Danh sách:** khoảng cách, hướng la bàn (B = Bắc, Đ = Đông, N = Nam, T = Tây), chênh lệch độ cao, “thấy lần đầu cách đây”,
  “đã tồn tại” và trạng thái. Các trạng thái: đang thấy, ngoài tầm nhìn (nhiều khả năng vẫn còn đó), đang được mở,
  đã mở (bởi bạn hoặc người chơi N), đã biến mất.
- **“Âm thanh” và “Thông báo”** trong trình duyệt phát âm thanh hoặc hiện thông báo trên màn hình mỗi khi có cube mới.
  Console cũng phát tiếng bíp (tắt bằng `--no-beep`).
- **Vị trí của bạn:** chỉ được cập nhật khi có sự kiện, ví dụ khi bạn thi triển buff hoặc bị tấn công. Thanh trên cùng cho
  biết vị trí đó cũ đến đâu. Khi không có vị trí mới, radar hiển thị một giá trị ước lượng kèm vòng tròn sai số.
- **Mini-radar trên game (overlay):** một cửa sổ nhỏ luôn nằm phía trước và không bao giờ lấy mất tiêu điểm của game.
  - Nội dung: Bắc ở trên, bạn ở giữa, các vòng tròn, tầm nhìn (~100 m) nét đứt và vệt di chuyển gần nhất của bạn. Vệt này
    cho biết bạn đến từ đâu, vì game không gửi hướng nhìn.
  - Cube hiện dưới dạng ▲/▼/■ (cao hơn, thấp hơn hoặc cùng độ cao) kèm chữ như “86 m ▲38”. Nếu cube nằm ngoài phạm vi zoom,
    một mũi tên » ở mép chỉ về hướng của nó.
  - Dòng đầu cho biết vị trí của bạn cũ đến đâu và mức zoom.
  - **Di chuyển:** `Ctrl+Shift+F11` mở cài đặt; khi cài đặt đang mở, overlay luôn hiện và có thể kéo bằng chuột.
    Vị trí được lưu khi bạn thả chuột.
  - **Zoom:** `Ctrl+Shift+F12`, hoặc lăn chuột trên overlay khi cài đặt đang mở (60 / 120 / 250 m).
  - **Tự ẩn / hiện:** chỉ hiển thị khi Aion 2 là cửa sổ đang hoạt động. Khi con trỏ chuột hiện ra (menu, chế độ giao diện),
    overlay cũng tự ẩn, kể cả khi con trỏ nằm ngay trên nó, để không che menu. Ngoại lệ: khi bạn giữ `Alt` (Aion 2 lúc đó
    hiện con trỏ), overlay vẫn hiện cho đến khi bạn thả phím.
    - Chỉ khi có quyền admin, nó mới biết `Alt` có đang được giữ: bản thân Aion 2 chạy với quyền admin và Windows giấu
      trạng thái phím khỏi các chương trình không có quyền. Vì vậy overlay tự khởi động lại một lần với quyền admin (hộp thoại UAC).
      Nếu bạn từ chối, nó vẫn chạy nhưng `Alt` sẽ làm overlay ẩn đi như khi mở menu. Trình duyệt và Explorer vẫn được mở
      không có quyền admin.
    - Chương trình chỉ đọc trạng thái cửa sổ, con trỏ chuột và phím của Windows, không đọc gì từ game.
    - Khi không có game đang chạy (phát lại), overlay luôn hiện.
    - Bạn có thể tắt việc ẩn khi mở menu trong `data\settings.json` bằng `"OverlayHideInMenus": false`, và chỉ tắt việc
      khởi động lại với quyền admin bằng `"OverlayAdminRights": false` (cả hai cũng có trong phần Cài đặt).
  - `Ctrl+Shift+F10` tắt hẳn rồi bật lại overlay.
  - Game phải chạy ở chế độ cửa sổ hoặc toàn màn hình không viền; trên chế độ toàn màn hình độc quyền thì không gì vẽ đè lên được.
  - Tắt overlay bằng `--no-overlay`.
- **Hướng Bắc:** cấu hình mặc định giả định trục thế giới −Y (chưa được xác nhận). Nếu hướng không khớp với minimap, hãy đổi ở ô
  “Hướng Bắc” phía trên. Lựa chọn này áp dụng cho cả overlay và được lưu trong `data\settings.json`.
- **Ghi dữ liệu:** mỗi phiên ghi `captures\radar_<ngày_giờ>\raw.pcapng` và `markers.jsonl`. Các phím tắt ở mục sau cũng dùng được ở đây.
- **Cơ sở dữ liệu:** mọi lần nhìn thấy cube được lưu vào `data\radar.db`. Xuất dữ liệu bằng liên kết “CSV” và “JSON” trong danh sách.
- **Tự kiểm tra:** nếu các gói tin cần thiết không xuất hiện (ví dụ sau một bản vá), một cảnh báo đỏ sẽ hiện lên. Các opcode nằm
  trong `config\radar.json`.
- **Khu vực khác:** khi một vật thể được mở bằng chìa khóa cube, hoặc nằm đúng trên một điểm đã biết, radar sẽ học template của nó
  làm template cube.

Phát lại để thử nghiệm: `.\cuberadar.cmd radar --replay captures\<phiên>\raw.pcapng --speed 5`. Với `--stop-at 200`,
quá trình phát lại dừng ở giây thứ 200 của bản ghi.

## Những gì đã loại bỏ so với bản gốc

Bản gốc có thêm chức năng thử nghiệm hiển thị người chơi phe đối địch. Bản này đã bỏ toàn bộ chức năng đó:
- Danh sách đối thủ, biểu tượng kim cương đỏ, số lượng đối thủ, tên / phe / cấp bậc PvP / khoảng cách.
- Lựa chọn “Ich spiele” / “Eigene Fraktion”, nút bật/tắt đối thủ, tùy chọn `--faction` và API `/api/faction`.
- Logic giải mã và theo dõi người chơi khác trong engine; opcode `player_*` không còn được ánh xạ.
- Các tùy chọn độ đục / kích thước dành riêng cho danh sách đối thủ.

Các chức năng Cube (nhận diện, vị trí, trạng thái, khoảng cách / hướng / độ cao, lịch sử, xuất dữ liệu, âm thanh, thông báo,
phím tắt, cập nhật) được giữ nguyên. Tệp `settings.json` và `radar.json` cũ vẫn dùng được; các khóa của tính năng đã bỏ được giữ
nguyên trong tệp để bạn có thể quay lại bản gốc bất cứ lúc nào.

## Ghi dữ liệu

```powershell
.\cuberadar.cmd dump live              # đến khi nhấn "q" + Enter hoặc Ctrl+C
.\cuberadar.cmd dump live --seconds 120
```

Mỗi bản ghi nằm trong `captures\<ngày_giờ>\`:
- `raw.pcapng`: gói tin thô để phát lại và mở bằng Wireshark
- `frames.jsonl`: mọi frame đã giải mã
- `markers.jsonl`: các điểm đánh dấu (marker) đã đặt
- `census.json` và `census.txt`: thống kê opcode và tình trạng luồng dữ liệu

**Marker** (mỗi phím có một tiếng bíp xác nhận):

| Phím tắt (toàn cục, dùng được trong game) | Marker |
|---|---|
| Ctrl+Shift+F5 | `cube_visible` (thấy cube) |
| Ctrl+Shift+F6 | `cube_opened` (cube đã mở) |
| Ctrl+Shift+F7 | `cube_out_of_sight` (cube ra ngoài tầm nhìn) |
| Ctrl+Shift+F8 | `cube_back` (cube quay lại tầm nhìn) |
| Ctrl+Shift+F9 | `note` (marker ghi chú chung) |

Trong console, Enter tạo một marker (có thể kèm ghi chú). `1`–`5` tương ứng với các phím tắt, `q` kết thúc ghi.
Muốn gán phím khác, dùng `--hotkeys "ctrl+alt+F1=cube_visible,…"`.

## Phân tích

```powershell
.\cuberadar.cmd dump captures\<phiên>\raw.pcapng     # phát lại -> raw.replay.jsonl (markers.jsonl được trộn vào)
.\cuberadar.cmd census captures\<phiên>\raw.pcapng
python tools\census.py captures\<phiên>\frames.jsonl
python tools\crosscheck.py captures\<phiên>\raw.pcapng captures\<phiên>\frames.jsonl
```

### frames.jsonl

Mỗi dòng là một đối tượng JSON. `t` là Unix-ms: với gói tin là đồng hồ bắt gói, với marker là đồng hồ treo tường.

- `frame`: `n` (số thứ tự), `t`, `flow`, `src` (`top` | `lz4` | `emb`), `depth`, `path`, `op` (byte trên đường truyền, dạng
  hex), `name`, `len` (thân), `wire` (frame gồm cả varint), `flag` (tùy chọn) và `hex` (thân không có opcode).
  - `path` mô tả cấu trúc lồng nhau: `B3.0/B4.2` là frame thứ ba trong bundle 4, và bundle 4 chính là frame đầu tiên của
    bundle 3. `E7.0` là một bundle được nhúng trong thân của một gói tin khác.
- `bundle`: `id`, `src`, `depth`, `path`, `host`, `raw`, `zlen`, `out`, `ok`
- `marker`: `t`, `local`, `label`, `text`, `via`
- ngoài ra còn `session`, `flow`, `gap`, `stats`

## Giấy phép

GPL-3.0 (xem `LICENSE`), vì một phần mã lấy từ cyberbadger6969/aion2-dps-meter. Các tệp dẫn xuất được ghi chú trong phần
chú thích đầu tệp. Dự án chỉ dành cho mục đích cá nhân. Việc sử dụng có thể vi phạm điều khoản của NCSOFT, rủi ro do người
dùng tự chịu.
