// Kiểm thử giao diện web (app.js + index.html) bằng Node, không cần trình duyệt: chạy `node --test tests/cube-ui.test.cjs`.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const wwwroot = path.join(__dirname, '../src/CubeRadar.Cli/wwwroot');

function browser() {
  const nodes = new Map(), calls = [], requested = new Set();
  const canvas = new Proxy({}, { get: (_, name) => (...args) => calls.push([name, ...args]),
    set: (_, name, value) => { calls.push(['set:' + name, value]); return true; } });
  const document = {
    documentElement: {}, activeElement: null,
    querySelectorAll: () => [],
    getElementById(id) {
      requested.add(id);
      if (!nodes.has(id)) nodes.set(id, {
        innerHTML: '', textContent: '', hidden: false, value: '', clientWidth: 800, clientHeight: 500,
        classList: { toggle() {} }, listeners: {},
        addEventListener(type, fn) { this.listeners[type] = fn; }, getContext: () => canvas,
      });
      return nodes.get(id);
    },
  };
  const context = vm.createContext({ document, console,
    localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    window: { addEventListener() {}, devicePixelRatio: 1 }, location: { host: '127.0.0.1' },
    getComputedStyle: () => ({ getPropertyValue: () => '#abcdef' }),
    WebSocket: class {}, setInterval() {}, setTimeout() {},
  });
  vm.runInContext(fs.readFileSync(path.join(wwwroot, 'app.js'), 'utf8'), context);
  const update = (cubes, extra = {}) => {
    const state = { radar: { nowMs: 10000, selfId: 1, cubes, warnings: [], trail: [], zone: null, mapId: 1, fixFreshSeconds: 5,
      self: { x: 10000, y: 10000, z: 100, timeMs: 10000, ageMs: 0, source: 'BuffA' }, ring: null,
      orientation: { north: '-y', northX: 0, northY: -1, eastX: 1, eastY: 0 }, ...extra },
      capture: { mode: 'replay', streams: 1, packets: 10 }, wallMs: 10000 };
    context.input = state;
    vm.runInContext('msg = input; onState();', context);
  };
  return { document, calls, context, update, requested };
}

const cube = (extra = {}) => ({ objectId: 65509, template: 1200039, zone: 'Verteron', learned: null, x: 12000, y: 11000, z: 1500,
  createdMs: 5000, firstSeenMs: 6000, lastSeenMs: 9000, status: 'Visible', statusSinceMs: 6000, openedBy: null, openedBySelf: false,
  mapId: 1010, note: null, ...extra });

test('trang HTML là tiếng Việt và không còn thành phần PvP', () => {
  const html = fs.readFileSync(path.join(wwwroot, 'index.html'), 'utf8');
  assert.match(html, /<html lang="vi">/);
  for (const id of ['enemies', 'faction', 'enemy-list', 'enemy-count', 'enemy-empty'])
    assert.ok(!html.includes(`id="${id}"`), `không được còn #${id}`);
  assert.doesNotMatch(html, /Gegner|Fraktion|Ich spiele|Karte|Reichweite|Norden|Ton aus|Hinweise/);
  assert.match(html, /Hướng Bắc/);
  assert.match(html, /Chưa có cube nào/);
});

test('danh sách cube hiển thị trạng thái, khoảng cách, hướng và độ cao bằng tiếng Việt', () => {
  const b = browser();
  b.update([cube()]);
  const html = b.document.getElementById('list').innerHTML;
  assert.match(html, /đang thấy/);
  assert.match(html, /cao hơn bạn 14 m/);            // (1500 − 100) / 100 m
  assert.match(html, /Template 1200039/);
  assert.match(html, /sao chép/);
  assert.match(html, /ĐN/);                           // cube nằm ở phía đông nam của bạn
  assert.doesNotMatch(html, /undefined|NaN/);
  assert.equal(b.document.getElementById('count').textContent, '(1 đang thấy)');
  assert.equal(b.document.getElementById('empty').hidden, true);
});

test('mọi trạng thái cube đều có văn bản tiếng Việt và độ cao thấp hơn / cùng độ cao được nhận ra', () => {
  const b = browser();
  b.update([
    cube({ objectId: 1, status: 'Opening', z: 100 }),
    cube({ objectId: 2, status: 'OutOfView', z: -900 }),
    cube({ objectId: 3, status: 'Opened', openedBySelf: true, openedBy: 1 }),
    cube({ objectId: 4, status: 'Gone' }),
  ]);
  const html = b.document.getElementById('list').innerHTML;
  assert.match(html, /đang được mở/);
  assert.match(html, /ngoài tầm nhìn/);
  assert.match(html, /đã mở \(bởi bạn\)/);
  assert.match(html, /đã biến mất/);
  assert.match(html, /≈ cùng độ cao/);
  assert.match(html, /thấp hơn bạn 10 m/);
});

test('không có cube: hiện thông báo trống; chưa biết vị trí: nói rõ bằng tiếng Việt', () => {
  const b = browser();
  b.update([], { self: null });
  assert.equal(b.document.getElementById('empty').hidden, false);
  assert.match(b.document.getElementById('chips').innerHTML, /Vị trí <b>chưa rõ<\/b>/);
  b.update([cube()], { self: null });
  assert.match(b.document.getElementById('list').innerHTML, /chưa rõ vị trí của bạn/);
});

test('thanh trạng thái có khu vực, ID của bạn, vị trí và không có chip phe phái', () => {
  const b = browser();
  b.update([cube()], { zone: 'Verteron' });
  const chips = b.document.getElementById('chips').innerHTML;
  assert.match(chips, /Khu vực/);
  assert.match(chips, /Bạn/);
  assert.match(chips, /Vị trí/);
  assert.doesNotMatch(chips, /Fraktion|Phe|phe/);
});

test('giao diện không đọc, không vẽ và không gọi API của đối thủ', () => {
  const b = browser();
  // Máy chủ cũ vẫn có thể gửi players / ownFaction: dữ liệu đó phải bị bỏ qua hoàn toàn.
  b.update([cube()], { players: [{ name: 'DoiThuX', isEnemy: true, faction: 'Asmodian', x: 10500, y: 10500, distanceM: 7 }],
    ownFaction: 'Elyos', factionSetting: 'Elyos' });
  for (const id of ['enemies', 'faction', 'enemy-list', 'enemy-count', 'enemy-empty'])
    assert.ok(!b.requested.has(id), `app.js không được truy cập #${id}`);
  assert.ok(!b.calls.some(c => c[0] === 'fillText' && String(c[1]).includes('DoiThuX')));
  assert.doesNotMatch(b.document.getElementById('list').innerHTML, /DoiThuX/);
});

test('radar vẽ cube, dải độ cao và nhãn tiếng Việt lên canvas', () => {
  const b = browser();
  b.update([cube()]);
  const texts = b.calls.filter(c => c[0] === 'fillText').map(c => String(c[1]));
  assert.ok(texts.includes('B ↑'));
  assert.ok(texts.includes('Độ cao'));
  assert.ok(texts.includes('bạn'));
  assert.ok(texts.some(t => /^\d+ m · ▲14$/.test(t)), texts.join('|'));
  assert.ok(texts.every(t => !/Höhe|\bdu\b/.test(t)));
});

test('cảnh báo từ máy chủ được hiển thị nguyên văn', () => {
  const b = browser();
  b.update([], { warnings: ['heartbeat (0036) đã 12 giây không thấy: chưa có luồng game'] });
  assert.equal(b.document.getElementById('warnings').hidden, false);
  assert.match(b.document.getElementById('warnings').innerHTML, /đã 12 giây không thấy/);
});

test('gợi ý trước / phải / trái theo hướng di chuyển, và chip hướng đi', () => {
  const b = browser();
  b.update([cube({ objectId: 1, relBearing: 40 }), cube({ objectId: 2, relBearing: -90 }), cube({ objectId: 3, relBearing: 180 }),
    cube({ objectId: 4, relBearing: 10, status: 'Gone' })], { headingDeg: 90, headingAgeMs: 2000 });
  const html = b.document.getElementById('list').innerHTML;
  assert.match(html, /↗ Trước-phải/);
  assert.match(html, /← Trái/);
  assert.match(html, /↓ Sau/);
  assert.equal((html.match(/class="facing"/g) || []).length, 3);   // cube đã biến mất không có gợi ý
  assert.match(b.document.getElementById('chips').innerHTML, /Hướng đi <b>Đ 90°<\/b>/);
});

test('chưa biết hướng di chuyển: không có gợi ý trái/phải, chip báo chưa rõ', () => {
  const b = browser();
  b.update([cube()]);
  assert.doesNotMatch(b.document.getElementById('list').innerHTML, /class="facing"/);
  assert.match(b.document.getElementById('chips').innerHTML, /Hướng đi <b>chưa rõ<\/b>/);
});
