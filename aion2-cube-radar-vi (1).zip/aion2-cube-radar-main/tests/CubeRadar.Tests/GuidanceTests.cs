using System.Buffers.Binary;
using CubeRadar.Core.Audio;
using CubeRadar.Core.Radar;

namespace CubeRadar.Tests;

/// <summary>Direction hints (ahead / right / …) and the proximity tick that get the player to the nearest cube.</summary>
public class GuidanceTests
{
    [Fact]
    public void Relative_bearing_is_positive_to_the_right_and_wraps()
    {
        Assert.Equal(90, Guidance.Relative(90, 0), 6);
        Assert.Equal(-90, Guidance.Relative(0, 90), 6);
        Assert.Equal(-20, Guidance.Relative(350, 10), 6);   // across north
        Assert.Equal(20, Guidance.Relative(10, 350), 6);
        Assert.Equal(180, Guidance.Relative(180, 0), 6);
        Assert.Equal(180, Guidance.Relative(0, 180), 6);    // −180 is reported as +180
    }

    [Fact]
    public void Eight_sectors_around_the_heading()
    {
        (double Rel, string Label)[] expected =
        [
            (0, "↑ Trước"), (44, "↗ Trước-phải"), (90, "→ Phải"), (135, "↘ Sau-phải"), (180, "↓ Sau"),
            (-135, "↙ Sau-trái"), (-90, "← Trái"), (-44, "↖ Trước-trái"), (22, "↑ Trước"), (23, "↗ Trước-phải"), (-22, "↑ Trước"),
        ];
        foreach (var (rel, label) in expected) Assert.Equal(label, Guidance.Label(rel));
        Assert.Equal("ĐB", Guidance.CompassVi(45));
        Assert.Equal("B", Guidance.CompassVi(359));
        Assert.Equal("TN", Guidance.CompassVi(225));
    }

    [Fact]
    public void Ticks_come_faster_and_higher_when_closer()
    {
        Assert.Equal(150, Guidance.PulseIntervalMs(0));
        Assert.Equal(150, Guidance.PulseIntervalMs(3));
        Assert.Equal(2000, Guidance.PulseIntervalMs(80));
        Assert.Equal(2000, Guidance.PulseIntervalMs(120));
        var last = 0;
        foreach (var d in new[] { 5.0, 10, 20, 40, 60, 79 })
        {
            var interval = Guidance.PulseIntervalMs(d);
            Assert.True(interval > last, $"{d} m: {interval} ms");
            last = interval;
        }
        Assert.True(Guidance.PitchHz(5, null) > Guidance.PitchHz(50, null));
        Assert.True(Guidance.PitchHz(20, 0) > Guidance.PitchHz(20, 180));      // behind sounds lower
        Assert.Equal(Guidance.PitchHz(20, null), Guidance.PitchHz(20, 0), 6);
    }

    [Fact]
    public void Pan_follows_left_and_right()
    {
        Assert.Equal(1, Guidance.Pan(90), 6);
        Assert.Equal(-1, Guidance.Pan(-90), 6);
        Assert.Equal(0, Guidance.Pan(0), 6);
        Assert.Equal(0, Guidance.Pan(null), 6);
    }

    private static (double Left, double Right) Energy(byte[] wav)
    {
        double l = 0, r = 0;
        var layout = WavVolume.Find(wav)!.Value;
        for (var i = layout.DataOffset; i + 4 <= layout.DataOffset + layout.DataLength; i += 4)
        {
            l += Math.Pow(BinaryPrimitives.ReadInt16LittleEndian(wav.AsSpan(i)), 2);
            r += Math.Pow(BinaryPrimitives.ReadInt16LittleEndian(wav.AsSpan(i + 2)), 2);
        }
        return (l, r);
    }

    [Fact]
    public void Tick_is_a_stereo_wav_with_the_sound_on_the_side_of_the_cube()
    {
        var left = ProximityTone.Tick(100, 900, -1);
        var right = ProximityTone.Tick(100, 900, 1);
        var centre = ProximityTone.Tick(100, 900, 0);
        Assert.NotNull(WavVolume.Find(left));
        Assert.Equal(2, BinaryPrimitives.ReadInt16LittleEndian(left.AsSpan(22)));       // stereo
        Assert.Equal(16, BinaryPrimitives.ReadInt16LittleEndian(left.AsSpan(34)));
        Assert.Equal(WavVolume.SampleRate * 70 / 1000 * 4, WavVolume.Find(left)!.Value.DataLength);

        var (ll, lr) = Energy(left);
        Assert.True(ll > 0 && lr < ll * 0.001, $"left L={ll} R={lr}");
        var (rl, rr) = Energy(right);
        Assert.True(rr > 0 && rl < rr * 0.001, $"right L={rl} R={rr}");
        var (cl, cr) = Energy(centre);
        Assert.Equal(cl, cr, cl * 0.001);
        Assert.Equal(cl + cr, ll + lr, (cl + cr) * 0.001);                              // constant power
    }

    [Fact]
    public void Tick_volume_scales_and_zero_volume_is_silent()
    {
        var loud = Energy(ProximityTone.Tick(100, 900, 0));
        var quiet = Energy(ProximityTone.Tick(50, 900, 0));
        Assert.True(quiet.Left < loud.Left);
        var mute = Energy(ProximityTone.Tick(0, 900, 0));
        Assert.Equal(0, mute.Left, 6);
        Assert.Equal(0, mute.Right, 6);
    }

    private static byte[] Teleport(float x, float y)
    {
        var body = new byte[24];
        BitConverter.GetBytes(x).CopyTo(body, 6);
        BitConverter.GetBytes(y).CopyTo(body, 10);
        BitConverter.GetBytes(50f).CopyTo(body, 14);
        return body;
    }

    [Fact]
    public void Heading_is_the_direction_of_the_last_movement_and_expires()
    {
        var engine = new RadarEngine(new RadarConfig());   // north = −Y, so +X is east
        engine.OnFrame(1_000, 0x3336, [0x01]);
        engine.OnFrame(2_000, 0x2336, Teleport(10_000, 10_000));
        Assert.Null(engine.Snapshot().HeadingDeg);          // one fix: no direction yet
        engine.OnFrame(5_000, 0x2336, Teleport(10_600, 10_000)); // 6 m east
        var s = engine.Snapshot();
        Assert.NotNull(s.HeadingDeg);
        Assert.Equal(90, s.HeadingDeg!.Value, 3);
        engine.OnFrame(8_000, 0x2336, Teleport(10_600, 9_400));  // 6 m towards −Y = north
        Assert.Equal(0, engine.Snapshot().HeadingDeg!.Value, 3);
        engine.OnFrame(9_000, 0x2336, Teleport(10_602, 9_400));  // moved only 2 m: heading hardly changes
        Assert.Equal(0, engine.Snapshot().HeadingDeg!.Value, 0.5);
        engine.OnFrame(40_000, 0x3336, [0x01]);                  // far later, nothing new
        Assert.Null(engine.Snapshot().HeadingDeg);               // expired after 20 s
    }

    [Fact]
    public void A_teleport_far_away_forgets_the_heading()
    {
        var engine = new RadarEngine(new RadarConfig());
        engine.OnFrame(1_000, 0x3336, [0x01]);
        engine.OnFrame(2_000, 0x2336, Teleport(10_000, 10_000));
        engine.OnFrame(5_000, 0x2336, Teleport(10_600, 10_000));
        Assert.NotNull(engine.Snapshot().HeadingDeg);
        engine.OnFrame(6_000, 0x2336, Teleport(90_000, 90_000)); // jump of > 1 km in 1 s
        Assert.Null(engine.Snapshot().HeadingDeg);
    }

    [Fact]
    public void Cube_relative_bearing_matches_bearing_minus_heading()
    {
        var engine = new RadarEngine(new RadarConfig { KeepGoneSeconds = 3600 });
        using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(
            Path.Combine(AppContext.BaseDirectory, "fixtures", "cubes", "2026-10-13_verteron_two_cubes.json")));
        foreach (var f in doc.RootElement.GetProperty("frames").EnumerateArray())
            engine.OnFrame(f.GetProperty("t").GetInt64(), Convert.ToUInt16(f.GetProperty("op").GetString(), 16),
                Convert.FromHexString(f.GetProperty("hex").GetString()!));
        var s = engine.Snapshot();
        Assert.Equal(2, s.Cubes.Count);
        foreach (var c in s.Cubes)
        {
            if (s.HeadingDeg is { } h && c.Bearing is { } b)
                Assert.Equal(Guidance.Relative(b, h), c.RelBearing!.Value, 6);
            else
                Assert.Null(c.RelBearing);
        }
    }
}
