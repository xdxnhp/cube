using System.Text.Json;
using CubeRadar.Core.Radar;

namespace CubeRadar.Tests;

/// <summary>Hidden Cube radar without player tracking: old config files still load, and player records of the game change
/// nothing about the cubes or the own position.</summary>
public class CubeOnlyTests
{
    private static List<(long T, ushort Op, byte[] Body)> CubeFrames()
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(
            Path.Combine(AppContext.BaseDirectory, "fixtures", "cubes", "2026-10-13_verteron_two_cubes.json")));
        return doc.RootElement.GetProperty("frames").EnumerateArray().Select(f => (
            f.GetProperty("t").GetInt64(),
            Convert.ToUInt16(f.GetProperty("op").GetString(), 16),
            Convert.FromHexString(f.GetProperty("hex").GetString()!))).ToList();
    }

    /// <summary>The state that matters for the cube radar (everything but the frame counter).</summary>
    private static string CubeState(RadarSnapshot s) =>
        JsonSerializer.Serialize(new { s.SelfId, s.MapId, s.Zone, s.Self, s.Ring, s.Trail, s.Cubes, s.Warnings });

    [Fact]
    public void Old_radar_json_with_player_opcodes_still_loads_and_ignores_them()
    {
        var dir = Directory.CreateTempSubdirectory("cuberadar_cfg_");
        try
        {
            var radar = Path.Combine(dir.FullName, "radar.json");
            File.WriteAllText(radar, """
                {
                  "opcodes": {
                    "heartbeat": "0036", "self_info": "3336", "map_load": "2136", "teleport": "2336",
                    "object_spawn": "3436", "object_removed": "3536", "open_start": "3836", "open_done": "3a36",
                    "pos_buff_a": "2a38", "pos_buff_b": "2b38", "pos_cast": "0238", "pos_target": "0e38",
                    "player_info": "4536", "player_removed": "4736", "player_killed": "048d",
                    "player_position": "1a37", "player_move": "1b37", "player_move_alt": "1c37", "player_move_velocity": "2937"
                  },
                  "self_id_opcodes": ["4a36", "4437"],
                  "self_check": [
                    { "kind": "heartbeat", "within_s": 10, "hint": "a" },
                    { "kind": "player_info", "within_s": 60, "hint": "b" }
                  ]
                }
                """);
            var cfg = RadarConfig.Load(radar, Path.Combine(dir.FullName, "cubes.json"), dir.FullName);
            Assert.Equal(12, cfg.Opcodes.Count);
            Assert.DoesNotContain(cfg.Opcodes.Keys, op => op is 0x4536 or 0x4736 or 0x048D or 0x1A37 or 0x1B37 or 0x1C37 or 0x2937);
            Assert.Equal(RecordKind.ObjectSpawn, cfg.Opcodes[0x3436]);
            Assert.Equal([RecordKind.Heartbeat], cfg.SelfCheck.Select(r => r.Kind));
            Assert.Contains((ushort)0x4A36, cfg.SelfIdOpcodes);
        }
        finally
        {
            dir.Delete(recursive: true);
        }
    }

    [Fact]
    public void Unknown_non_player_record_kind_in_radar_json_is_still_rejected()
    {
        var dir = Directory.CreateTempSubdirectory("cuberadar_cfg_");
        try
        {
            var radar = Path.Combine(dir.FullName, "radar.json");
            File.WriteAllText(radar, """{ "opcodes": { "no_such_kind": "0036" }, "self_id_opcodes": [] }""");
            Assert.Throws<FormatException>(() => RadarConfig.Load(radar, Path.Combine(dir.FullName, "cubes.json"), dir.FullName));
        }
        finally
        {
            dir.Delete(recursive: true);
        }
    }

    [Fact]
    public void Default_config_carries_no_player_opcodes()
    {
        var cfg = new RadarConfig();
        Assert.Equal(12, cfg.Opcodes.Count);
        Assert.DoesNotContain(cfg.Opcodes.Keys, op => op is 0x4536 or 0x4736 or 0x048D or 0x1A37 or 0x1B37 or 0x1C37 or 0x2937);
        Assert.All(Enum.GetNames<RecordKind>(), n => Assert.DoesNotContain("Player", n));
    }

    [Fact]
    public void Player_records_in_the_stream_change_neither_cubes_nor_own_position()
    {
        var frames = CubeFrames();
        var plain = new RadarEngine(new RadarConfig { KeepGoneSeconds = 3600 });
        var noisy = new RadarEngine(new RadarConfig { KeepGoneSeconds = 3600 });
        ushort[] playerOpcodes = [0x4536, 0x4736, 0x048D, 0x1A37, 0x1B37, 0x1C37, 0x2937];
        foreach (var (t, op, body) in frames)
        {
            plain.OnFrame(t, op, body);
            noisy.OnFrame(t, op, body);
            foreach (var p in playerOpcodes) noisy.OnFrame(t, p, Synth.Body(48, (byte)p)); // other players' records
        }

        Assert.Equal(CubeState(plain.Snapshot()), CubeState(noisy.Snapshot()));
        var s = noisy.Snapshot();
        Assert.Equal(9180u, s.SelfId);
        Assert.Equal(2, s.Cubes.Count);
        Assert.NotNull(s.Self);
        Assert.All(s.Cubes, c =>
        {
            Assert.Equal(nameof(CubeStatus.Opened), c.Status);
            Assert.True(c.OpenedBySelf);
            Assert.NotNull(c.DistanceM);
            Assert.NotNull(c.Bearing);
            Assert.NotNull(c.DzUnits);
        });
    }

    [Fact]
    public void Snapshot_json_has_no_player_or_faction_fields()
    {
        var engine = new RadarEngine(new RadarConfig());
        foreach (var (t, op, body) in CubeFrames()) engine.OnFrame(t, op, body);
        var json = JsonSerializer.Serialize(engine.Snapshot(), new JsonSerializerOptions(JsonSerializerDefaults.Web));
        Assert.DoesNotContain("players", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("faction", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("rank", json, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("\"cubes\"", json);
        Assert.Contains("\"self\"", json);
    }

    [Fact]
    public void Teleport_and_map_load_still_give_the_own_position()
    {
        var engine = new RadarEngine(new RadarConfig());
        // 23 36: 6 bytes, then x y z (f32), u32, u16 — own position after a teleport (docs/FINDINGS.md P2).
        var body = new byte[6 + 12 + 6];
        BitConverter.GetBytes(1234f).CopyTo(body, 6);
        BitConverter.GetBytes(-5678f).CopyTo(body, 10);
        BitConverter.GetBytes(90f).CopyTo(body, 14);
        engine.OnFrame(1000, 0x3336, [0x01]);   // self info: id 1 (voter)
        engine.OnFrame(1100, 0x2336, body);
        var s = engine.Snapshot();
        Assert.Equal(1u, s.SelfId);
        Assert.NotNull(s.Self);
        Assert.Equal(1234, s.Self!.X, 0.01);
        Assert.Equal(-5678, s.Self.Y, 0.01);
    }

    [Fact]
    public void Self_check_warnings_are_in_vietnamese()
    {
        var cfg = new RadarConfig { SelfCheck = [new SelfCheckRule(RecordKind.ObjectSpawn, 5, "gợi ý")] };
        var engine = new RadarEngine(cfg);
        engine.OnFrame(1_000, 0x0036, new byte[8]);
        var early = engine.SelfCheck(20_000);
        Assert.Contains(early, w => w.Contains("đã 19 giây không thấy") && w.Contains("gợi ý"));
        var late = engine.SelfCheck(40_000);
        Assert.Contains(late, w => w.Contains("chưa biết ID thực thể"));
        Assert.DoesNotContain(early.Concat(late), w => w.Contains("seit") || w.Contains("nicht") || w.Contains("unbekannt"));
    }
}
