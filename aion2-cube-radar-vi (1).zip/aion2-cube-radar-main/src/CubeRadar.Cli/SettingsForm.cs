using System.Drawing;
using System.Windows.Forms;

namespace CubeRadar.Cli;

/// <summary>What the overlay and its settings window can ask the radar to do.</summary>
internal sealed record OverlayActions(
    Action OpenWeb,
    Action Quit,
    Action TestSound,
    Func<string> GetNorth,
    Action<string> SetNorth,
    Action OpenCaptures,
    Updater? Updater = null);

/// <summary>
/// Settings opened from the overlay's gear button (or the tray). Every change applies at once and is saved; there is
/// no OK / Cancel. Runs on the overlay's UI thread.
/// </summary>
internal sealed class SettingsForm : Form
{
    private static readonly Color Bg = Color.FromArgb(22, 27, 33), Field = Color.FromArgb(32, 39, 47), Fg = Color.FromArgb(230, 235, 240),
        Muted = Color.FromArgb(139, 150, 163), Accent = Color.FromArgb(77, 163, 255), Danger = Color.FromArgb(255, 107, 91);

    private static readonly (string Value, string Text)[] Norths =
        [("-y", "−Y (mặc định)"), ("+y", "+Y"), ("+x", "+X"), ("-x", "−X")];

    private bool _preview;

    /// <summary>The PNG preview must not steal the focus from the game.</summary>
    protected override bool ShowWithoutActivation => _preview;

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        var dark = 1;
        DwmSetWindowAttribute(Handle, 20, ref dark, sizeof(int)); // DWMWA_USE_IMMERSIVE_DARK_MODE: dark title bar
    }

    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

    public SettingsForm(RadarSettings settings, OverlayActions actions, Action applied, Action resetPosition, Action confirmUpdate)
    {
        Text = "Cube Radar – Cài đặt";
        Icon = OverlayWindow.AppIcon();
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        TopMost = true;
        ShowInTaskbar = true;
        BackColor = Bg;
        ForeColor = Fg;
        Font = new Font("Segoe UI", 9.5f);
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        Padding = new Padding(16, 12, 16, 12);

        void Save()
        {
            settings.Save();
            applied();
        }

        var grid = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, Dock = DockStyle.Fill, BackColor = Bg };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

        void Section(string title)
        {
            var l = new Label { Text = title, AutoSize = true, ForeColor = Accent, Font = new Font(Font, FontStyle.Bold), Margin = new Padding(0, 10, 0, 4) };
            grid.Controls.Add(l);
            grid.SetColumnSpan(l, 2);
        }

        void Row(string label, Control control)
        {
            grid.Controls.Add(new Label { Text = label, AutoSize = true, ForeColor = Fg, Anchor = AnchorStyles.Left, Margin = new Padding(0, 6, 12, 6) });
            control.Margin = new Padding(0, 3, 0, 3);
            grid.Controls.Add(control);
        }

        void Full(Control control)
        {
            grid.Controls.Add(control);
            grid.SetColumnSpan(control, 2);
        }

        // ---- sound
        Section("Âm thanh khi có cube mới");
        var sound = Check("Phát âm thanh", settings.SoundEnabled);
        sound.CheckedChanged += (_, _) => { settings.SoundEnabled = sound.Checked; Save(); };
        var test = Btn("Thử");
        test.Click += (_, _) => actions.TestSound();
        Full(Flow(sound, test));

        var volume = new TrackBar { Minimum = 5, Maximum = 100, TickFrequency = 10, SmallChange = 5, LargeChange = 10, Width = 200,
            Value = Math.Clamp(settings.SoundVolumePct, 5, 100), BackColor = Bg };
        var volumeText = new Label { AutoSize = true, ForeColor = Muted, Text = $"{volume.Value} %", Margin = new Padding(6, 8, 0, 0) };
        // Play the sound at the new volume once the slider rests (not on every step while dragging).
        var preview = new System.Windows.Forms.Timer { Interval = 200 };
        preview.Tick += (_, _) => { preview.Stop(); actions.TestSound(); };
        Disposed += (_, _) => preview.Dispose();
        volume.ValueChanged += (_, _) =>
        {
            settings.SoundVolumePct = volume.Value;
            volumeText.Text = $"{volume.Value} %";
            Save();
            preview.Stop();
            preview.Start();
        };
        Row("Âm lượng", Flow(volume, volumeText));

        var file = new TextBox { Width = 230, ReadOnly = true, BackColor = Field, ForeColor = Fg, BorderStyle = BorderStyle.FixedSingle, Text = settings.SoundFile ?? "" };
        var browse = Btn("Chọn tệp …");
        browse.Click += (_, _) =>
        {
            using var dlg = new OpenFileDialog { Filter = "Tệp WAV (*.wav)|*.wav", Title = "Âm thanh cho cube mới" };
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            settings.SoundFile = file.Text = dlg.FileName;
            Save();
        };
        var clear = Btn("Tiếng bíp mặc định");
        clear.Click += (_, _) => { settings.SoundFile = null; file.Text = ""; Save(); };
        Row("Tệp .wav riêng (tùy chọn)", Flow(file, browse, clear));

        var proximity = Check("Tiếng tích dồn dập hơn khi đến gần cube", settings.ProximitySound);
        var stereo = Check("Tiếng tích nghiêng về bên trái/phải theo hướng cube (nên dùng tai nghe)", settings.ProximityStereo);
        stereo.Enabled = proximity.Checked;
        proximity.CheckedChanged += (_, _) => { settings.ProximitySound = proximity.Checked; stereo.Enabled = proximity.Checked; Save(); };
        stereo.CheckedChanged += (_, _) => { settings.ProximityStereo = stereo.Checked; Save(); };
        Full(proximity);
        Full(stereo);
        Full(new Label { Text = "Game không gửi hướng nhìn của nhân vật, nên “trước / phải / trái” được tính theo hướng bạn đang di chuyển. " +
                                "Khi đứng yên hoặc chỉ xoay camera, hướng có thể sai hoặc chưa rõ (khi đó chỉ có tiếng tích ở giữa). " +
                                "Tiếng tích chỉ cập nhật khi game gửi vị trí mới của bạn.",
            AutoSize = true, ForeColor = Muted, MaximumSize = new Size(420, 0), Margin = new Padding(0, 0, 0, 4) });

        // ---- overlay look
        Section("Overlay");
        var range = Combo(OverlayWindow.Ranges.Select(r => $"{r} m"), Array.IndexOf(OverlayWindow.Ranges, settings.OverlayRangeM));
        range.SelectedIndexChanged += (_, _) => { settings.OverlayRangeM = OverlayWindow.Ranges[range.SelectedIndex]; Save(); };
        Row("Zoom (cũng có thể lăn chuột)", range);

        int[] scales = [75, 100, 125, 150];
        var scale = Combo(scales.Select(s => $"{s} %"), Array.IndexOf(scales, settings.OverlayScalePct));
        scale.SelectedIndexChanged += (_, _) => { settings.OverlayScalePct = scales[scale.SelectedIndex]; Save(); };
        Row("Kích thước", scale);

        TrackBar Opacity(string label, int value, Action<int> set)
        {
            var bar = new TrackBar { Minimum = 40, Maximum = 100, TickFrequency = 10, SmallChange = 5, LargeChange = 10, Width = 200,
                Value = Math.Clamp(value, 40, 100), BackColor = Bg };
            var text = new Label { AutoSize = true, ForeColor = Muted, Text = $"{bar.Value} %", Margin = new Padding(6, 8, 0, 0) };
            bar.ValueChanged += (_, _) => { set(bar.Value); text.Text = $"{bar.Value} %"; Save(); };
            Row(label, Flow(bar, text));
            return bar;
        }
        Opacity("Độ đục của radar", settings.OverlayOpacityPct, v => settings.OverlayOpacityPct = v);

        var north = Combo(Norths.Select(n => n.Text), Math.Max(0, Array.FindIndex(Norths, n => n.Value == actions.GetNorth())));
        north.SelectedIndexChanged += (_, _) => actions.SetNorth(Norths[north.SelectedIndex].Value);
        Row("Hướng Bắc", north);
        Full(new Label { Text = "Nếu hướng không khớp với minimap trong game, hãy đổi ở đây (áp dụng cho cả giao diện web).",
            AutoSize = true, ForeColor = Muted, MaximumSize = new Size(420, 0), Margin = new Padding(0, 0, 0, 4) });

        // ---- visibility
        Section("Khi nào overlay được hiển thị?");
        var focus = Check("Chỉ khi Aion 2 đang ở cửa sổ phía trước", settings.OverlayOnlyWhenGameFocused);
        focus.CheckedChanged += (_, _) => { settings.OverlayOnlyWhenGameFocused = focus.Checked; Save(); };
        Full(focus);
        var menus = Check("Ẩn khi mở menu (trong lúc con trỏ chuột đang hiện)", settings.OverlayHideInMenus);
        menus.CheckedChanged += (_, _) => { settings.OverlayHideInMenus = menus.Checked; Save(); };
        Full(menus);
        var admin = Check("Chạy với quyền admin để nhận biết phím Alt", settings.OverlayAdminRights);
        admin.CheckedChanged += (_, _) => { settings.OverlayAdminRights = admin.Checked; Save(); };
        admin.Enabled = menus.Checked;
        menus.CheckedChanged += (_, _) => admin.Enabled = menus.Checked;
        admin.Margin = new Padding(20, 3, 0, 0);
        Full(admin);
        Full(new Label { Text = "Khi giữ Alt trong Aion 2, con trỏ chuột sẽ hiện ra. Cube Radar chỉ biết Alt có đang được giữ hay không " +
                                "khi có quyền admin (bản thân Aion 2 chạy với quyền này); nếu không, Alt sẽ làm overlay ẩn đi như khi mở menu. " +
                                "Có hiệu lực từ lần khởi động sau, Windows sẽ hỏi xác nhận." +
                                (Elevation.IsElevated ? "" : "\nHiện Cube Radar đang chạy không có quyền admin."),
            AutoSize = true, ForeColor = Muted, MaximumSize = new Size(400, 0), Margin = new Padding(20, 0, 0, 4) });

        // ---- updates (single exe only)
        if (actions.Updater is { } updater)
        {
            Section("Cập nhật");
            var auto = Check("Tự động tìm bản cập nhật (khi khởi động và mỗi 6 giờ, trên GitHub)", settings.UpdateCheckEnabled);
            auto.CheckedChanged += (_, _) => updater.SetEnabled(auto.Checked);
            Full(auto);
            var state = new Label { AutoSize = true, ForeColor = Muted, MaximumSize = new Size(420, 0), Margin = new Padding(0, 2, 0, 2) };
            var check = Btn("Kiểm tra ngay");
            check.Click += (_, _) => _ = updater.CheckAsync();
            var install = Btn("Cập nhật ngay");
            install.Click += (_, _) => confirmUpdate();
            var page = Btn("Các phiên bản trên GitHub");
            page.Click += (_, _) => updater.OpenPage();
            void Refresh()
            {
                state.Text = $"Đang dùng: {Updater.Current.ToString(3)} · {updater.State}";
                check.Enabled = !updater.Installing;
                install.Enabled = updater.Available is not null && !updater.Installing;
            }
            void OnChanged()
            {
                try
                {
                    if (IsHandleCreated) BeginInvoke(Refresh);
                }
                catch (Exception ex) when (ex is InvalidOperationException or ObjectDisposedException)
                {
                    // the window is closing
                }
            }
            Refresh();
            updater.Changed += OnChanged;
            Disposed += (_, _) => updater.Changed -= OnChanged;
            Full(state);
            Full(Flow(check, install, page));
        }

        // ---- actions
        Section("Khác");
        var reset = Btn("Đặt lại vị trí");
        reset.Click += (_, _) => resetPosition();
        var web = Btn("Mở giao diện web");
        web.Click += (_, _) => actions.OpenWeb();
        var captures = Btn("Mở thư mục bản ghi");
        captures.Click += (_, _) => actions.OpenCaptures();
        Full(Flow(reset, web, captures));
        Full(new Label { Text = "Khi cửa sổ này đang mở, overlay luôn hiển thị: kéo bằng chuột để di chuyển, " +
                                "lăn chuột trên overlay để zoom.\nPhím tắt (Ctrl+Shift): F10 = bật/tắt overlay · F11 = mở/đóng cài đặt · F12 = đổi zoom",
            AutoSize = true, ForeColor = Muted, MaximumSize = new Size(420, 0), Margin = new Padding(0, 8, 0, 0) });

        var quit = Btn("Thoát radar");
        quit.ForeColor = Danger;
        quit.FlatAppearance.BorderColor = Danger;
        quit.Click += (_, _) => { Close(); actions.Quit(); };
        var close = Btn("Đóng");
        close.Click += (_, _) => Close();
        var bottom = Flow(quit, close);
        bottom.Margin = new Padding(0, 14, 0, 0);
        Full(bottom);

        Controls.Add(grid);
    }

    /// <summary>Renders the window to a PNG without showing it (for checking the layout).</summary>
    public static void SavePng(string path, RadarSettings settings, OverlayActions actions)
    {
        var t = new Thread(() =>
        {
            // Controls are only created when the window is shown: show it far off-screen, without taking the focus.
            using var form = new SettingsForm(settings, actions, () => { }, () => { }, () => { })
            {
                StartPosition = FormStartPosition.Manual,
                Location = new Point(-30_000, -30_000),
                ShowInTaskbar = false,
                _preview = true,
            };
            form.Show();
            Application.DoEvents();
            using var bmp = new Bitmap(form.Width, form.Height);
            form.DrawToBitmap(bmp, new Rectangle(0, 0, form.Width, form.Height));
            bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
        });
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
        t.Join();
    }

    private static CheckBox Check(string text, bool value) =>
        new() { Text = text, Checked = value, AutoSize = true, ForeColor = Fg, Margin = new Padding(0, 3, 0, 3) };

    private static Button Btn(string text)
    {
        var b = new Button { Text = text, AutoSize = true, FlatStyle = FlatStyle.Flat, BackColor = Field, ForeColor = Fg, Padding = new Padding(6, 1, 6, 1) };
        b.FlatAppearance.BorderColor = Color.FromArgb(60, 70, 82);
        return b;
    }

    private static ComboBox Combo(IEnumerable<string> items, int selected)
    {
        var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 140, BackColor = Field, ForeColor = Fg, FlatStyle = FlatStyle.Flat };
        c.Items.AddRange(items.Cast<object>().ToArray());
        c.SelectedIndex = Math.Max(0, selected);
        return c;
    }

    private static FlowLayoutPanel Flow(params Control[] controls)
    {
        var f = new FlowLayoutPanel { AutoSize = true, WrapContents = false, BackColor = Bg, Margin = new Padding(0) };
        foreach (var c in controls)
        {
            c.Margin = new Padding(0, 3, 8, 3);
            f.Controls.Add(c);
        }
        return f;
    }
}
