using System.Globalization;
using CubeRadar.Cli;
using CubeRadar.Core.Capture;
using CubeRadar.Core.Dump;
using CubeRadar.Core.Protocol;

// aion2-cube-radar developer tool. Strictly passive: reads packets through Npcap, never sends anything to the game or
// alters it. The only internet access is the optional update check of the single exe (Updater).
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// A downloaded update, started by the old radar to take its place (see Updater).
if (args is [Updater.InstallFlag, .. var install]) return Updater.RunInstaller(install);

AppPaths.Init();
var book = File.Exists(AppPaths.Config("opcodes.json")) ? OpcodeBook.Load(AppPaths.Config("opcodes.json")) : OpcodeBook.Empty;

// The updater restarts the new exe with the previous arguments plus --after-update.
var afterUpdate = args.Contains(Updater.AfterUpdateFlag);
if (afterUpdate) args = [.. args.Where(x => x != Updater.AfterUpdateFlag)];

// Double-clicked "Cube Radar.exe" (no console, no arguments): just the overlay.
if (args.Length == 0 && !NativeConsole.HasConsole) args = ["radar", "--overlay-only"];

try
{
    return args.FirstOrDefault() switch
    {
        "devices" => Devices(),
        "conns" => Connections(),
        "dump" when args.Length > 1 && args[1] == "live" => DumpLive(args[2..]),
        "dump" when args.Length > 1 => DumpFile(args[1], args[2..], writeJsonl: true),
        "census" when args.Length > 1 => DumpFile(args[1], args[2..], writeJsonl: false),
        "radar" => RadarCommand.Run(args[1..], book, afterUpdate),
        "--version" => Print(DumpSession.Version),
        "--quit" => Quit(),
        _ => Usage(),
    };
}
catch (Exception ex) when (!NativeConsole.HasConsole && ex is not FormatException)
{
    NativeConsole.Notify($"Cube Radar đã dừng do gặp lỗi:\n\n{ex.GetType().Name}: {ex.Message}\n\nDữ liệu và log: {AppPaths.DataRoot}");
    return 1;
}
catch (FormatException ex)
{
    Console.Error.WriteLine(ex.Message);
    return 2;
}

int Usage()
{
    Console.WriteLine($"""
        cuberadar {DumpSession.Version} - radar Hidden Cube cho AION 2 (chỉ đọc thụ động qua Npcap)

        cuberadar devices                          liệt kê các card mạng Npcap
        cuberadar conns                            các tiến trình AION 2 và kết nối TCP của chúng
        cuberadar dump live [tùy chọn]             ghi dữ liệu trực tiếp vào captures/<ngày_giờ>/:
                                                   raw.pcapng, frames.jsonl, markers.jsonl, census.json/.txt
            --out DIR          thư mục gốc của phiên ghi (mặc định: <dự án>/captures)
            --device NAME      chọn card mạng Npcap (xem 'devices'); mặc định: card đang chạy game
            --seconds N        dừng sau N giây (mặc định: đến khi nhấn 'q' hoặc Ctrl+C)
            --hotkeys SPEC     phím tắt đánh dấu, mặc định:
                               {GlobalHotkeys.DefaultSpec}
            --no-hotkeys       chỉ đánh dấu bằng console
            --no-beep          không phát tiếng bíp xác nhận khi đánh dấu
            --no-heartbeat     không ghi frame heartbeat vào frames.jsonl (vẫn được đếm)
            --no-embedded      không tìm gói LZ4 nhúng bên trong thân gói tin
        cuberadar dump <file.pcap|.pcapng> [--out DIR] [--markers FILE] [--no-heartbeat] [--no-embedded]
                                                   giải mã một bản ghi thành <tên>.replay.jsonl + thống kê;
                                                   markers.jsonl nằm cạnh tệp sẽ được gộp tự động
        cuberadar census <file.pcap|.pcapng>       chỉ thống kê opcode và tình trạng luồng dữ liệu
        cuberadar radar [tùy chọn]                 radar Hidden Cube trực tiếp tại http://127.0.0.1:5313
            --port N           cổng web (mặc định 5313)
            --device NAME      chọn card mạng Npcap
            --replay FILE      phát lại một tệp .pcap/.pcapng thay vì bắt gói tin trực tiếp
            --speed X          tốc độ phát lại (mặc định 1; 0 = nhanh nhất có thể)
            --stop-at S        dừng phát lại sau S giây của bản ghi (để xem đúng thời điểm đó)
            --no-record        không ghi raw.pcapng vào captures/radar_<ngày_giờ>/
            --no-hotkeys, --hotkeys SPEC, --no-beep   giống 'dump live' (tiếng bíp cũng phát khi có cube mới)
            --no-browser       không mở trình duyệt
            --no-overlay       không dùng overlay mini radar (Ctrl+Shift+F10 bật/tắt, F11 cài đặt: kéo overlay
                               khi cài đặt đang mở, F12 đổi zoom)
            --overlay-only     chỉ chạy overlay: không mở trình duyệt, ẩn console (log nằm trong thư mục phiên ghi);
                               dùng biểu tượng khay hệ thống để mở giao diện web hoặc thoát
        cuberadar --quit                           yêu cầu radar đang chạy đóng lại (giống “Thoát” ở khay hệ thống)
        cuberadar --version                        in ra phiên bản

        Console khi chạy 'dump live': Enter = đánh dấu (có thể nhập ghi chú), 1-5 = các đánh dấu theo phím tắt, q = dừng.
        """);
    return 1;
}

int Print(string s)
{
    Console.WriteLine(s);
    return 0;
}

int Quit()
{
    EventWaitHandle? signal;
    try
    {
        if (!EventWaitHandle.TryOpenExisting(RadarCommand.QuitSignalName, out signal))
        {
            Console.WriteLine("hiện không có radar nào đang chạy");
            return 1;
        }
    }
    catch (UnauthorizedAccessException)
    {
        Console.WriteLine("radar đang chạy có quyền admin: hãy thoát từ biểu tượng khay hệ thống, hoặc chạy lệnh này bằng quyền administrator");
        return 1;
    }
    using (signal) signal.Set();
    Console.WriteLine("đã yêu cầu radar thoát");
    return 0;
}

int Devices()
{
    foreach (var (name, desc) in LiveSniffer.ListDevices()) Console.WriteLine($"{desc,-60} {name}");
    return 0;
}

int Connections()
{
    var pids = GameProcessLocator.FindGameProcessIds();
    Console.WriteLine($"tiến trình AION 2: {(pids.Length == 0 ? "không có" : string.Join(", ", pids))}");
    foreach (var c in GameProcessLocator.FindConnections(pids))
        Console.WriteLine($"  {c.LocalIp}:{c.LocalPort} -> {c.RemoteIp}:{c.RemotePort}{(c.RemotePort == StreamTracker.GamePort ? "  (cổng game)" : "")}");
    return 0;
}

int DumpFile(string path, string[] a, bool writeJsonl)
{
    if (!File.Exists(path))
    {
        Console.Error.WriteLine($"không tìm thấy tệp: {path}");
        return 2;
    }
    var options = ParseDumpOptions(a);
    var dir = Opt(a, "--out") ?? Path.GetDirectoryName(Path.GetFullPath(path))!;
    Directory.CreateDirectory(dir);
    var stem = Path.GetFileNameWithoutExtension(path);
    var jsonl = writeJsonl ? Path.Combine(dir, stem + ".replay.jsonl") : null;
    var census = Path.Combine(dir, stem + ".replay.census.json");

    using var session = new DumpSession(book, options, jsonl);
    session.Jsonl?.Session("file", Path.GetFullPath(path), DumpSession.Version);
    var markerFile = Opt(a, "--markers") ?? Path.Combine(Path.GetDirectoryName(Path.GetFullPath(path))!, "markers.jsonl");
    if (File.Exists(markerFile))
    {
        var markers = DumpSession.ReadMarkerLog(markerFile);
        session.QueueReplayMarkers(markers);
        Console.WriteLine($"đánh dấu: {markers.Count} mục từ {markerFile}");
    }
    session.FlowLocked += f => Console.WriteLine($"luồng dữ liệu game {f.Id}: {f.Key}{(f.Aligned ? " (từ gói SYN)" : " (vào giữa luồng)")}");

    var packets = CaptureFileSource.ReadAll(path, raw => session.OnPacket(raw, "file"));
    var report = session.Finish(census);
    Console.WriteLine($"đã đọc {packets:N0} gói tin");
    Console.WriteLine(report);
    File.WriteAllText(Path.ChangeExtension(census, ".txt"), report);
    if (jsonl is not null) Console.WriteLine($"frame: {jsonl}");
    Console.WriteLine($"thống kê: {census}");
    return 0;
}

int DumpLive(string[] a)
{
    if (!LiveSniffer.IsNpcapInstalled())
    {
        Console.Error.WriteLine("Chưa cài Npcap (https://npcap.com).");
        return 2;
    }
    var options = ParseDumpOptions(a);
    var root = Opt(a, "--out") ?? AppPaths.Captures;
    var dir = Path.Combine(root, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
    Directory.CreateDirectory(dir);
    var seconds = Opt(a, "--seconds") is { } s ? int.Parse(s, CultureInfo.InvariantCulture) : 0;
    var beep = !a.Contains("--no-beep");
    var bindings = a.Contains("--no-hotkeys") ? [] : GlobalHotkeys.Parse(Opt(a, "--hotkeys") ?? GlobalHotkeys.DefaultSpec);

    using var session = new DumpSession(book, options,
        Path.Combine(dir, "frames.jsonl"), Path.Combine(dir, "raw.pcapng"), Path.Combine(dir, "markers.jsonl"));
    session.Jsonl!.Session("live", Opt(a, "--device") ?? "auto", DumpSession.Version);
    session.FlowLocked += f => Log($"luồng dữ liệu game {f.Id}: {f.Key}{(f.Aligned ? " (từ gói SYN)" : " (vào giữa luồng)")}");

    using var sniffer = new LiveSniffer(new LiveSnifferOptions { DeviceName = Opt(a, "--device") });
    sniffer.PacketArrived += (raw, dev) => session.OnPacket(raw, dev.Name, LiveSniffer.Describe(dev));
    sniffer.StatusChanged += st => Log(st + (sniffer.Filter is { } f ? $" · bộ lọc: {f}" : ""));

    using var stop = new ManualResetEventSlim();
    Console.CancelKeyPress += (_, e) =>
    {
        e.Cancel = true;
        stop.Set();
    };

    using var markers = new MarkerInput(session, bindings, beep, stop.Set);
    Console.WriteLine($"phiên ghi: {dir}");
    markers.PrintHelp();

    sniffer.Start();
    var started = DateTime.UtcNow;
    var lastStats = DateTime.UtcNow;
    while (!stop.Wait(5_000))
    {
        var line = session.Read(x =>
        {
            var c = x.Census;
            long Count(ushort op) => c.Ops.TryGetValue(op, out var st) ? st.Count : 0;
            var flows = x.Tracker.GameFlows;
            return $"gói tin {x.Packets:N0} · luồng {flows.Count} · frame {c.Frames:N0} · hb {c.HeartbeatRate:N1}/s · " +
                   $"spawn 41 36: {Count(0x4136)} · 34 36: {Count(0x3436)} · bundle {c.BundlesOk:N0} (lỗi {c.BundlesBad}) · " +
                   $"đồng bộ lại {flows.Sum(f => f.Decoder.Resyncs)} · mất gói {flows.Sum(f => f.Reassembler.Gaps)} · đánh dấu {c.Markers}";
        });
        var health = sniffer.Health();
        Log(line + (health is { } h ? $" · Npcap bỏ sót {h.Dropped}" : ""));
        if (DateTime.UtcNow - lastStats > TimeSpan.FromSeconds(10))
        {
            session.WriteStats(health);
            lastStats = DateTime.UtcNow;
        }
        if (seconds > 0 && DateTime.UtcNow - started > TimeSpan.FromSeconds(seconds)) break;
    }

    var npcap = sniffer.Health();
    sniffer.Stop();
    var report = session.Finish(Path.Combine(dir, "census.json"), npcap);
    File.WriteAllText(Path.Combine(dir, "census.txt"), report);
    Console.WriteLine(report);
    Console.WriteLine($"phiên ghi: {dir}");
    return 0;
}

DumpOptions ParseDumpOptions(string[] a) => new()
{
    WriteHeartbeats = !a.Contains("--no-heartbeat"),
    ScanEmbedded = !a.Contains("--no-embedded"),
};

static string? Opt(string[] a, string name) =>
    Array.IndexOf(a, name) is var i and >= 0 && i + 1 < a.Length ? a[i + 1] : null;

static void Log(string message) => Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] {message}");
