using CubeRadar.Core.Audio;
using CubeRadar.Core.Radar;

namespace CubeRadar.Cli;

/// <summary>
/// The proximity sound: while a cube is in range, a short tick whose rhythm gets faster and whose pitch rises the closer the
/// cube is; with stereo on it is panned to the side of the cube (relative to the direction we are moving) and a cube behind
/// us sounds lower. Quiet while the overlay is hidden (game not in front, a menu open), right after the new-cube sound,
/// and when our position is more than a minute old.
/// </summary>
internal sealed class ProximityBeeper : IDisposable
{
    private const int PollMs = 50;
    private const int AfterChimeMs = 900;
    private const int MaxPositionAgeMs = 60_000;
    private readonly Func<RadarSnapshot> _snapshot;
    private readonly RadarSettings _settings;
    private readonly Func<bool> _active;
    private readonly CancellationTokenSource _stop = new();
    private readonly Thread _thread;
    private long _lastTick = long.MinValue / 2;

    public ProximityBeeper(Func<RadarSnapshot> snapshot, RadarSettings settings, Func<bool> active)
    {
        (_snapshot, _settings, _active) = (snapshot, settings, active);
        _thread = new Thread(Run) { IsBackground = true, Name = "proximity" };
        _thread.Start();
    }

    private void Run()
    {
        while (!_stop.Token.WaitHandle.WaitOne(PollMs))
        {
            try
            {
                Step();
            }
            catch (Exception)
            {
                // sound is a convenience: never let it take the radar down
            }
        }
    }

    private void Step()
    {
        if (!_settings.SoundEnabled || !_settings.ProximitySound || !_active()) return;
        var now = Environment.TickCount64;
        if (now - CubeSound.LastChimeTick < AfterChimeMs) return;
        var s = _snapshot();
        if (s.Self is not { } self || self.AgeMs > MaxPositionAgeMs) return;
        var target = s.Cubes.Where(c => c.Status is nameof(CubeStatus.Visible) or nameof(CubeStatus.Opening) && c.DistanceM is <= Guidance.FarM)
            .MinBy(c => c.DistanceM);
        if (target?.DistanceM is not { } distance) return;
        if (now - _lastTick < Guidance.PulseIntervalMs(distance)) return;
        _lastTick = now;
        var rel = _settings.ProximityStereo ? target.RelBearing : null;
        CubeSound.PlayTick(ProximityTone.Tick(_settings.SoundVolumePct, Guidance.PitchHz(distance, rel), Guidance.Pan(rel)));
    }

    public void Dispose()
    {
        _stop.Cancel();
        _thread.Join(500);
        _stop.Dispose();
    }
}
