namespace CubeRadar.Core.Radar;

/// <summary>
/// Short "walk this way" hints for the nearest cube, relative to the direction we are moving. The game never sends the
/// facing direction, so the heading is the direction of our last movement (see <see cref="RadarEngine"/>); without a
/// recent one only the compass direction is available.
/// Relative bearing: 0 = straight ahead, +90 = right, −90 = left, ±180 = behind.
/// </summary>
public static class Guidance
{
    /// <summary>Closer than this the tick is at its fastest.</summary>
    public const double NearM = 3;
    /// <summary>Farther than this (the send radius is about 100 m) the tick is at its slowest.</summary>
    public const double FarM = 80;

    private static readonly string[] Arrows = ["↑", "↗", "→", "↘", "↓", "↙", "←", "↖"];
    private static readonly string[] Names = ["Trước", "Trước-phải", "Phải", "Sau-phải", "Sau", "Sau-trái", "Trái", "Trước-trái"];
    private static readonly string[] Compass = ["B", "ĐB", "Đ", "ĐN", "N", "TN", "T", "TB"];

    /// <summary>−180..180 (right is positive) for a cube at <paramref name="bearing"/> when we head <paramref name="heading"/>.</summary>
    public static double Relative(double bearing, double heading)
    {
        var d = (bearing - heading) % 360;
        if (d > 180) d -= 360;
        else if (d <= -180) d += 360;
        return d;
    }

    /// <summary>0 = ahead, then clockwise in steps of 45°: 1 ahead-right, 2 right, 3 behind-right, 4 behind, 5 behind-left, 6 left, 7 ahead-left.</summary>
    public static int Sector(double relBearing)
    {
        var r = (relBearing % 360 + 360) % 360;
        return (int)Math.Floor((r + 22.5) / 45) % 8;
    }

    /// <summary>E.g. "↗ Trước-phải".</summary>
    public static string Label(double relBearing)
    {
        var s = Sector(relBearing);
        return $"{Arrows[s]} {Names[s]}";
    }

    /// <summary>Vietnamese compass letters: B Bắc, Đ Đông, N Nam, T Tây.</summary>
    public static string CompassVi(double bearing) => Compass[(int)Math.Round(((bearing % 360 + 360) % 360) / 45) % 8];

    /// <summary>Time between two ticks: 150 ms close to the cube, 2 s at the edge of the range.</summary>
    public static int PulseIntervalMs(double distanceM)
    {
        var t = Math.Clamp((distanceM - NearM) / (FarM - NearM), 0, 1);
        return (int)Math.Round(150 + t * 1850);
    }

    /// <summary>Pitch: rises as we come closer (650 → 1300 Hz); a cube behind us sounds lower (down to 75 %), because left/right
    /// panning alone cannot tell ahead from behind.</summary>
    public static double PitchHz(double distanceM, double? relBearing)
    {
        var t = Math.Clamp((distanceM - NearM) / (FarM - NearM), 0, 1);
        var hz = 650 + (1 - t) * 650;
        if (relBearing is { } rel) hz *= 0.75 + 0.25 * (1 + Math.Cos(rel * Math.PI / 180)) / 2;
        return hz;
    }

    /// <summary>−1 = fully left, +1 = fully right, 0 = centred (also when the heading is unknown).</summary>
    public static double Pan(double? relBearing) => relBearing is { } rel ? Math.Sin(rel * Math.PI / 180) : 0;
}
