using System.Buffers.Binary;

namespace CubeRadar.Core.Audio;

/// <summary>The short tick of the proximity sound: 16-bit stereo WAV bytes with constant-power panning. Pure byte work.</summary>
public static class ProximityTone
{
    private const double Peak = 0.6;

    /// <param name="pan">−1 left … +1 right.</param>
    public static byte[] Tick(int volumePct, double hz, double pan, int ms = 70)
    {
        var rate = WavVolume.SampleRate;
        var n = rate * ms / 1000;
        var angle = (Math.Clamp(pan, -1, 1) + 1) * Math.PI / 4; // 0 = left only, π/2 = right only
        double left = Math.Cos(angle), right = Math.Sin(angle);
        var amplitude = WavVolume.Gain(volumePct) * Peak * short.MaxValue;
        var attack = Math.Max(1, rate * 3 / 1000);
        var data = n * 4;
        var wav = new byte[44 + data];
        var s = wav.AsSpan();
        "RIFF"u8.CopyTo(s);
        BinaryPrimitives.WriteInt32LittleEndian(s[4..], 36 + data);
        "WAVEfmt "u8.CopyTo(s[8..]);
        BinaryPrimitives.WriteInt32LittleEndian(s[16..], 16);
        BinaryPrimitives.WriteInt16LittleEndian(s[20..], 1); // PCM
        BinaryPrimitives.WriteInt16LittleEndian(s[22..], 2); // stereo
        BinaryPrimitives.WriteInt32LittleEndian(s[24..], rate);
        BinaryPrimitives.WriteInt32LittleEndian(s[28..], rate * 4);
        BinaryPrimitives.WriteInt16LittleEndian(s[32..], 4);
        BinaryPrimitives.WriteInt16LittleEndian(s[34..], 16);
        "data"u8.CopyTo(s[36..]);
        BinaryPrimitives.WriteInt32LittleEndian(s[40..], data);
        for (var i = 0; i < n; i++)
        {
            var decay = 1.0 - (double)i / n;
            var envelope = Math.Min(1.0, (double)i / attack) * decay * decay;
            var v = Math.Sin(2 * Math.PI * hz * i / rate) * envelope * amplitude;
            BinaryPrimitives.WriteInt16LittleEndian(s[(44 + 4 * i)..], (short)Math.Round(v * left));
            BinaryPrimitives.WriteInt16LittleEndian(s[(46 + 4 * i)..], (short)Math.Round(v * right));
        }
        return wav;
    }
}
